# Modul 335 - Übungen ML
Dies ist die offizielle Musterlösung aller Modul 335 Übungen. Die passenden Kursunterlagen sind zu finden unter [https://m335.ict-bz.ch](https://m335.ict-bz.ch)


## Usage
```bash
git clone https://github.com/IctBerufsbildungZentralschweiz/modul-335-ml-uebungen.git

cd modul-335-ml-uebungen

npm i

ionic serve
```