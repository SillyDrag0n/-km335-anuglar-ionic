export const environment = {
  production: true,
   version: '1.2.3'
};
