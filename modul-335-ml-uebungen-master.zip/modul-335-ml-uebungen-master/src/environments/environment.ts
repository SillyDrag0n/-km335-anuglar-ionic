export const environment = {
    production: false,
    m335GroupNumber: 0,
    firebaseConfig: {
        apiKey: 'AIzaSyDJgmwqHki4FjNxduVqkoYUQIp8G0QYyOo',
        authDomain: 'm335-uebungen.firebaseapp.com',
        databaseURL: 'https://m335-uebungen.firebaseio.com',
        projectId: 'm335-uebungen',
        storageBucket: 'm335-uebungen.appspot.com',
        messagingSenderId: '675049996439',
        appId: '1:675049996439:web:9b2aed3cfc2b9fabe669d2',
    },
};
