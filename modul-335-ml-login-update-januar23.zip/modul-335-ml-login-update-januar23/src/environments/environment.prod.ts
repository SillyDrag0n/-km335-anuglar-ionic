export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: 'AIzaSyArTTnqykFNgwBRL8IldPCFn8dobVVghBI',
    authDomain: 'm335-login.firebaseapp.com',
    databaseURL: 'https://m335-login.firebaseio.com',
    projectId: 'm335-login',
    storageBucket: 'm335-login.appspot.com',
    messagingSenderId: '14955115856',
    appId: '1:14955115856:web:d53930b7c82b6d01106855'
}
};
