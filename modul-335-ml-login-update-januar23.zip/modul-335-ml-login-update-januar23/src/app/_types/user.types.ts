export class User {
    email: string;
    password: string;
    displayname?: string;
}
